import { useState } from 'react';
import { ProfileSetup } from './components/ProfileSetup';
import { Dashboard } from './components/Dashboard';
import { IDVerification } from './components/IDVerification';

export interface UserProfile {
  id: string;
  name: string;
  age: number;
  gender: string;
  location: string;
  zipCode: string;
  hasChildren: boolean;
  numberOfChildren?: number;
  hasPets: boolean;
  petType?: string;
  hasDisability: boolean;
  disabilityType?: string;
  employmentStatus: string;
  veteranStatus: boolean;
  lgbtqStatus: boolean;
  highestEducation: string;
  isVerified: boolean;
}

export interface Resource {
  id: string;
  name: string;
  type: 'shelter' | 'food' | 'healthcare' | 'employment' | 'legal' | 'other';
  address: string;
  phone: string;
  hours: string;
  requirements: string[];
  capacity?: number;
  acceptsChildren?: boolean;
  acceptsPets?: boolean;
  wheelchairAccessible?: boolean;
  veteranPriority?: boolean;
  matchScore?: number;
}

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [showVerification, setShowVerification] = useState(false);

  const handleProfileComplete = (profile: UserProfile) => {
    setCurrentUser(profile);
  };

  const handleVerificationRequest = () => {
    setShowVerification(true);
  };

  const handleVerificationComplete = () => {
    if (currentUser) {
      setCurrentUser({ ...currentUser, isVerified: true });
      setShowVerification(false);
    }
  };

  const handleEditProfile = () => {
    setCurrentUser(null);
    setShowVerification(false);
  };

  if (!currentUser) {
    return <ProfileSetup onComplete={handleProfileComplete} />;
  }

  if (showVerification) {
    return (
      <IDVerification
        onComplete={handleVerificationComplete}
        onCancel={() => setShowVerification(false)}
      />
    );
  }

  return (
    <Dashboard
      user={currentUser}
      onRequestVerification={handleVerificationRequest}
      onEditProfile={handleEditProfile}
    />
  );
}