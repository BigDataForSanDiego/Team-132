import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Resource } from '../App';
import { MapPin, Phone, Clock, CheckCircle2, Users, PawPrint, Accessibility, FileText } from 'lucide-react';

interface ResourceCardProps {
  resource: Resource;
}

const typeColors = {
  shelter: 'bg-orange-500',
  food: 'bg-emerald-500',
  healthcare: 'bg-rose-500',
  employment: 'bg-purple-500',
  legal: 'bg-amber-500',
  other: 'bg-teal-500',
};

const typeLabels = {
  shelter: 'Shelter',
  food: 'Food',
  healthcare: 'Healthcare',
  employment: 'Employment',
  legal: 'Legal Aid',
  other: 'Other Services',
};

export function ResourceCard({ resource }: ResourceCardProps) {
  const matchScore = resource.matchScore || 0;
  const isHighMatch = matchScore >= 70;

  return (
    <Card className={`relative ${isHighMatch ? 'ring-2 ring-green-500' : ''}`}>
      {isHighMatch && (
        <div className="absolute -top-2 -right-2">
          <Badge className="bg-green-500 hover:bg-green-600">
            {matchScore}% Match
          </Badge>
        </div>
      )}
      
      <CardHeader>
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            <CardTitle className="mb-2">{resource.name}</CardTitle>
            <Badge className={typeColors[resource.type]}>
              {typeLabels[resource.type]}
            </Badge>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3">
        <div className="flex items-start gap-2 text-sm">
          <MapPin className="size-4 mt-0.5 text-muted-foreground flex-shrink-0" />
          <span>{resource.address}</span>
        </div>
        
        <div className="flex items-center gap-2 text-sm">
          <Phone className="size-4 text-muted-foreground flex-shrink-0" />
          <a href={`tel:${resource.phone}`} className="hover:underline">
            {resource.phone}
          </a>
        </div>
        
        <div className="flex items-start gap-2 text-sm">
          <Clock className="size-4 mt-0.5 text-muted-foreground flex-shrink-0" />
          <span>{resource.hours}</span>
        </div>

        {/* Features */}
        <div className="flex flex-wrap gap-2">
          {resource.acceptsChildren && (
            <Badge variant="secondary" className="text-xs">
              <Users className="size-3 mr-1" />
              Families
            </Badge>
          )}
          {resource.acceptsPets && (
            <Badge variant="secondary" className="text-xs">
              <PawPrint className="size-3 mr-1" />
              Pets OK
            </Badge>
          )}
          {resource.wheelchairAccessible && (
            <Badge variant="secondary" className="text-xs">
              <Accessibility className="size-3 mr-1" />
              Accessible
            </Badge>
          )}
        </div>

        {/* Requirements */}
        {resource.requirements && resource.requirements.length > 0 && (
          <div className="pt-2 border-t">
            <p className="text-xs text-muted-foreground mb-1">Requirements:</p>
            <ul className="text-xs space-y-1">
              {resource.requirements.map((req, idx) => (
                <li key={idx} className="flex items-start gap-1">
                  <CheckCircle2 className="size-3 mt-0.5 text-muted-foreground flex-shrink-0" />
                  <span>{req}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <Button className="w-full mt-4" variant={isHighMatch ? 'default' : 'outline'}>
          Get Directions
        </Button>
      </CardContent>
    </Card>
  );
}