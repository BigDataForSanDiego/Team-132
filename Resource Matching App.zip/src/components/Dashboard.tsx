import { useState, useMemo } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { UserProfile, Resource } from '../App';
import { ResourceCard } from './ResourceCard';
import { UserMatching } from './UserMatching';
import { Shield, ShieldAlert, User, LogOut } from 'lucide-react';

interface DashboardProps {
  user: UserProfile;
  onRequestVerification: () => void;
  onEditProfile: () => void;
}

// Mock resources data
const mockResources: Resource[] = [
  {
    id: '1',
    name: 'Hope Haven Shelter',
    type: 'shelter',
    address: '123 Main St, Downtown',
    phone: '(555) 123-4567',
    hours: '24/7 - Check-in after 6 PM',
    requirements: ['Photo ID (driver\'s license, state ID, or passport)', 'Intake interview', 'Proof of homelessness (if available)'],
    capacity: 50,
    acceptsChildren: true,
    acceptsPets: false,
    wheelchairAccessible: true,
    veteranPriority: true,
  },
  {
    id: '2',
    name: 'Community Food Bank',
    type: 'food',
    address: '456 Oak Ave, Northside',
    phone: '(555) 234-5678',
    hours: 'Mon-Fri: 9 AM - 5 PM, Sat: 9 AM - 2 PM',
    requirements: ['No ID required', 'Proof of address helpful but not required'],
    acceptsChildren: true,
  },
  {
    id: '3',
    name: 'Pet-Friendly Shelter',
    type: 'shelter',
    address: '789 Elm St, Westside',
    phone: '(555) 345-6789',
    hours: 'Daily: 5 PM - 8 AM',
    requirements: ['Photo ID required', 'Proof of pet vaccination', 'Pet must be on leash or in carrier'],
    capacity: 30,
    acceptsChildren: false,
    acceptsPets: true,
    wheelchairAccessible: false,
  },
  {
    id: '4',
    name: 'Veterans Resource Center',
    type: 'other',
    address: '321 Liberty Blvd, Central',
    phone: '(555) 456-7890',
    hours: 'Mon-Fri: 8 AM - 6 PM',
    requirements: ['DD-214 or proof of service', 'Valid ID (any type)', 'VA healthcare card (if available)'],
    veteranPriority: true,
    wheelchairAccessible: true,
  },
  {
    id: '5',
    name: 'Free Health Clinic',
    type: 'healthcare',
    address: '654 Park Lane, Southside',
    phone: '(555) 567-8901',
    hours: 'Tue, Thu: 10 AM - 4 PM',
    requirements: ['No ID required', 'Insurance card if you have one', 'Walk-ins welcome'],
    wheelchairAccessible: true,
  },
  {
    id: '6',
    name: 'Job Training Center',
    type: 'employment',
    address: '987 Commerce Dr, Industrial',
    phone: '(555) 678-9012',
    hours: 'Mon-Fri: 9 AM - 5 PM',
    requirements: ['Social Security card or birth certificate', 'Valid ID required for job placement', 'Resume helpful but not required'],
  },
  {
    id: '7',
    name: 'Family Shelter Network',
    type: 'shelter',
    address: '147 Family Way, Eastside',
    phone: '(555) 789-0123',
    hours: '24/7 - Call ahead',
    requirements: ['Parent/guardian ID required', 'Birth certificates for children', 'Must have children under 18'],
    capacity: 25,
    acceptsChildren: true,
    acceptsPets: false,
    wheelchairAccessible: true,
  },
  {
    id: '8',
    name: 'Daily Bread Soup Kitchen',
    type: 'food',
    address: '258 Church St, Downtown',
    phone: '(555) 890-1234',
    hours: 'Breakfast: 7-9 AM, Dinner: 5-7 PM',
    requirements: ['No ID required', 'No documentation needed'],
    acceptsChildren: true,
  },
  {
    id: '9',
    name: 'Career Pathways Program',
    type: 'employment',
    address: '432 Skills Blvd, Midtown',
    phone: '(555) 901-2345',
    hours: 'Mon-Thu: 10 AM - 6 PM',
    requirements: ['Valid photo ID', 'Social Security card', 'High school diploma or GED (for some programs)', 'Work permit if under 18'],
  },
  {
    id: '10',
    name: 'Quick Hire Temp Agency',
    type: 'employment',
    address: '765 Work Plaza, Industrial',
    phone: '(555) 012-3456',
    hours: 'Mon-Fri: 6 AM - 4 PM',
    requirements: ['Two forms of ID (one photo ID)', 'Social Security card required', 'Background check consent form', 'Direct deposit info or voided check'],
  },
];

export function Dashboard({ user, onRequestVerification, onEditProfile }: DashboardProps) {
  const [selectedType, setSelectedType] = useState<string>('all');

  // Calculate match scores based on user profile
  const matchedResources = useMemo(() => {
    return mockResources.map((resource) => {
      let score = 50; // Base score

      // Boost score for matching criteria
      if (user.hasChildren && resource.acceptsChildren) score += 20;
      if (user.hasPets && resource.acceptsPets) score += 20;
      if (user.hasDisability && resource.wheelchairAccessible) score += 15;
      if (user.veteranStatus && resource.veteranPriority) score += 25;

      // Penalize for mismatches
      if (user.hasChildren && resource.acceptsChildren === false) score -= 30;
      if (user.hasPets && resource.acceptsPets === false) score -= 30;
      if (user.hasDisability && resource.wheelchairAccessible === false) score -= 20;

      return { ...resource, matchScore: Math.max(0, Math.min(100, score)) };
    }).sort((a, b) => (b.matchScore || 0) - (a.matchScore || 0));
  }, [user]);

  const filteredResources = selectedType === 'all'
    ? matchedResources
    : matchedResources.filter(r => r.type === selectedType);

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-purple-100">
      <div className="container mx-auto p-4 max-w-6xl">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="mb-2">Welcome, {user.name}</h1>
            <div className="flex items-center gap-2">
              {user.isVerified ? (
                <Badge className="bg-green-500 hover:bg-green-600">
                  <Shield className="size-3 mr-1" />
                  Verified
                </Badge>
              ) : (
                <Badge variant="secondary">
                  <ShieldAlert className="size-3 mr-1" />
                  Not Verified
                </Badge>
              )}
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onEditProfile}>
              <User className="size-4 mr-2" />
              Edit Profile
            </Button>
            <Button variant="ghost" size="sm" onClick={onEditProfile}>
              <LogOut className="size-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>

        {/* Verification Alert */}
        {!user.isVerified && (
          <Alert className="mb-6 border-orange-200 bg-orange-50">
            <ShieldAlert className="size-4" />
            <AlertDescription>
              <div className="flex items-center justify-between">
                <span>
                  Verify your ID to unlock community connections and connect with others who can help
                </span>
                <Button size="sm" onClick={onRequestVerification} className="ml-4">
                  Verify ID
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="resources" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="resources">My Resources</TabsTrigger>
            <TabsTrigger value="community" disabled={!user.isVerified}>
              Community {!user.isVerified && '🔒'}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="resources" className="space-y-4">
            {/* Filter buttons */}
            <div className="flex gap-2 flex-wrap">
              <Button
                variant={selectedType === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedType('all')}
              >
                All Resources
              </Button>
              <Button
                variant={selectedType === 'shelter' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedType('shelter')}
              >
                Shelter
              </Button>
              <Button
                variant={selectedType === 'food' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedType('food')}
              >
                Food
              </Button>
              <Button
                variant={selectedType === 'healthcare' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedType('healthcare')}
              >
                Healthcare
              </Button>
              <Button
                variant={selectedType === 'employment' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedType('employment')}
              >
                Employment
              </Button>
            </div>

            {/* Resources list */}
            <div className="grid gap-4 md:grid-cols-2">
              {filteredResources.map((resource) => (
                <ResourceCard key={resource.id} resource={resource} />
              ))}
            </div>

            {filteredResources.length === 0 && (
              <Card>
                <CardContent className="py-8 text-center text-muted-foreground">
                  No resources found for this category
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="community">
            <UserMatching user={user} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}