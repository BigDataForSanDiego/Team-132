import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Shield, Upload, CheckCircle2, AlertCircle } from 'lucide-react';

interface IDVerificationProps {
  onComplete: () => void;
  onCancel: () => void;
}

export function IDVerification({ onComplete, onCancel }: IDVerificationProps) {
  const [step, setStep] = useState<'upload' | 'processing' | 'success'>('upload');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;

    setStep('processing');
    
    // Simulate verification process
    setTimeout(() => {
      setStep('success');
      setTimeout(() => {
        onComplete();
      }, 2000);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-purple-100 p-4 flex items-center justify-center">
      <Card className="w-full max-w-lg">
        <CardHeader>
          <div className="flex items-center gap-2 mb-2">
            <Shield className="size-6 text-orange-600" />
            <CardTitle>ID Verification</CardTitle>
          </div>
          <CardDescription>
            Verify your identity to unlock community features and connect with others
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          {step === 'upload' && (
            <form onSubmit={handleSubmit} className="space-y-6">
              <Alert>
                <AlertCircle className="size-4" />
                <AlertDescription>
                  Your ID will be used only for verification purposes. We protect your privacy and security.
                </AlertDescription>
              </Alert>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="id-type">Accepted ID Types</Label>
                  <ul className="text-sm space-y-1 text-muted-foreground ml-4">
                    <li>• Driver's License</li>
                    <li>• State ID Card</li>
                    <li>• Passport</li>
                    <li>• Military ID</li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="id-upload">Upload ID Photo</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-orange-400 transition-colors">
                    <Input
                      id="id-upload"
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                    <label htmlFor="id-upload" className="cursor-pointer">
                      <Upload className="size-12 mx-auto mb-2 text-gray-400" />
                      <p className="mb-1">
                        {selectedFile ? selectedFile.name : 'Click to upload or drag and drop'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        PNG, JPG up to 10MB
                      </p>
                    </label>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
                  Cancel
                </Button>
                <Button type="submit" disabled={!selectedFile} className="flex-1">
                  Verify ID
                </Button>
              </div>
            </form>
          )}

          {step === 'processing' && (
            <div className="py-12 text-center">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-gray-200 border-t-orange-600 mb-4"></div>
              <p className="text-muted-foreground">
                Verifying your ID...
              </p>
            </div>
          )}

          {step === 'success' && (
            <div className="py-12 text-center">
              <CheckCircle2 className="size-16 text-green-500 mx-auto mb-4" />
              <h3 className="mb-2">Verification Complete!</h3>
              <p className="text-muted-foreground">
                You now have full access to community features
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}