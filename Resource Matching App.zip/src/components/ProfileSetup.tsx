import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { UserProfile } from '../App';

interface ProfileSetupProps {
  onComplete: (profile: UserProfile) => void;
}

export function ProfileSetup({ onComplete }: ProfileSetupProps) {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: '',
    location: '',
    zipCode: '',
    hasChildren: false,
    numberOfChildren: '',
    hasPets: false,
    petType: '',
    hasDisability: false,
    disabilityType: '',
    employmentStatus: '',
    veteranStatus: false,
    lgbtqStatus: false,
    highestEducation: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const profile: UserProfile = {
      id: Math.random().toString(36).substr(2, 9),
      name: formData.name,
      age: parseInt(formData.age),
      gender: formData.gender,
      location: formData.location,
      zipCode: formData.zipCode,
      hasChildren: formData.hasChildren,
      numberOfChildren: formData.hasChildren ? parseInt(formData.numberOfChildren) : undefined,
      hasPets: formData.hasPets,
      petType: formData.hasPets ? formData.petType : undefined,
      hasDisability: formData.hasDisability,
      disabilityType: formData.hasDisability ? formData.disabilityType : undefined,
      employmentStatus: formData.employmentStatus,
      veteranStatus: formData.veteranStatus,
      lgbtqStatus: formData.lgbtqStatus,
      highestEducation: formData.highestEducation,
      isVerified: false,
    };

    onComplete(profile);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-purple-100 p-4 flex items-center justify-center">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Welcome to EquiMatch</CardTitle>
          <CardDescription>
            Please complete your profile to get matched with resources that can help you
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="age">Age</Label>
                <Input
                  id="age"
                  type="number"
                  min="1"
                  max="120"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="gender">Gender</Label>
                <Select
                  value={formData.gender}
                  onValueChange={(value) => setFormData({ ...formData, gender: value })}
                  required
                >
                  <SelectTrigger id="gender">
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="non-binary">Non-binary</SelectItem>
                    <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Current Location (City)</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="zipCode">Zip Code</Label>
                <Input
                  id="zipCode"
                  value={formData.zipCode}
                  onChange={(e) => setFormData({ ...formData, zipCode: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="employment">Employment Status</Label>
                <Select
                  value={formData.employmentStatus}
                  onValueChange={(value) => setFormData({ ...formData, employmentStatus: value })}
                  required
                >
                  <SelectTrigger id="employment">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unemployed">Unemployed</SelectItem>
                    <SelectItem value="part-time">Part-time</SelectItem>
                    <SelectItem value="temporary">Temporary</SelectItem>
                    <SelectItem value="looking">Looking for work</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="education">Highest Education</Label>
                <Select
                  value={formData.highestEducation}
                  onValueChange={(value) => setFormData({ ...formData, highestEducation: value })}
                  required
                >
                  <SelectTrigger id="education">
                    <SelectValue placeholder="Select education" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="some-hs">Some High School</SelectItem>
                    <SelectItem value="hs-diploma">High School Diploma/GED</SelectItem>
                    <SelectItem value="some-college">Some College</SelectItem>
                    <SelectItem value="associates">Associate's Degree</SelectItem>
                    <SelectItem value="bachelors">Bachelor's Degree</SelectItem>
                    <SelectItem value="postgraduate">Postgraduate Degree</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="veteran"
                  checked={formData.veteranStatus}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, veteranStatus: checked as boolean })
                  }
                />
                <Label htmlFor="veteran" className="cursor-pointer">
                  I am a veteran
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="lgbtq"
                  checked={formData.lgbtqStatus}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, lgbtqStatus: checked as boolean })
                  }
                />
                <Label htmlFor="lgbtq" className="cursor-pointer">
                  I identify as LGBTQ+
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="children"
                  checked={formData.hasChildren}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, hasChildren: checked as boolean })
                  }
                />
                <Label htmlFor="children" className="cursor-pointer">
                  I have children with me
                </Label>
              </div>

              {formData.hasChildren && (
                <div className="ml-6 space-y-2">
                  <Label htmlFor="numChildren">Number of children</Label>
                  <Input
                    id="numChildren"
                    type="number"
                    min="1"
                    value={formData.numberOfChildren}
                    onChange={(e) => setFormData({ ...formData, numberOfChildren: e.target.value })}
                    required
                  />
                </div>
              )}

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="pets"
                  checked={formData.hasPets}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, hasPets: checked as boolean })
                  }
                />
                <Label htmlFor="pets" className="cursor-pointer">
                  I have pets
                </Label>
              </div>

              {formData.hasPets && (
                <div className="ml-6 space-y-2">
                  <Label htmlFor="petType">Type of pet</Label>
                  <Input
                    id="petType"
                    value={formData.petType}
                    onChange={(e) => setFormData({ ...formData, petType: e.target.value })}
                    placeholder="e.g., dog, cat"
                    required
                  />
                </div>
              )}

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="disability"
                  checked={formData.hasDisability}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, hasDisability: checked as boolean })
                  }
                />
                <Label htmlFor="disability" className="cursor-pointer">
                  I have a disability or special need
                </Label>
              </div>

              {formData.hasDisability && (
                <div className="ml-6 space-y-2">
                  <Label htmlFor="disabilityType">Please describe (optional)</Label>
                  <Input
                    id="disabilityType"
                    value={formData.disabilityType}
                    onChange={(e) => setFormData({ ...formData, disabilityType: e.target.value })}
                    placeholder="e.g., mobility, vision"
                  />
                </div>
              )}
            </div>

            <Button type="submit" className="w-full">
              Find My Resources
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}