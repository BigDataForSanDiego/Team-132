import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { UserProfile } from '../App';
import { MessageCircle, Users, Heart } from 'lucide-react';

interface UserMatchingProps {
  user: UserProfile;
}

// Mock user data for matching
const mockUsers = [
  {
    id: '1',
    name: 'Maria G.',
    age: 34,
    location: 'Downtown',
    hasChildren: true,
    numberOfChildren: 2,
    commonNeeds: ['Childcare resources', 'Food assistance'],
    matchScore: 85,
  },
  {
    id: '2',
    name: 'James R.',
    age: 52,
    location: 'Northside',
    veteranStatus: true,
    commonNeeds: ['Veterans services', 'Healthcare'],
    matchScore: 78,
  },
  {
    id: '3',
    name: 'Lisa M.',
    age: 29,
    location: 'Westside',
    hasPets: true,
    commonNeeds: ['Pet-friendly shelter', 'Employment help'],
    matchScore: 72,
  },
  {
    id: '4',
    name: 'David K.',
    age: 45,
    location: 'Eastside',
    hasDisability: true,
    commonNeeds: ['Accessible housing', 'Healthcare'],
    matchScore: 68,
  },
];

export function UserMatching({ user }: UserMatchingProps) {
  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="size-5" />
            Community Connections
          </CardTitle>
          <CardDescription>
            Connect with others in similar situations who can share experiences and support
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        {mockUsers.map((matchedUser) => (
          <Card key={matchedUser.id}>
            <CardHeader>
              <div className="flex items-start gap-4">
                <Avatar className="h-12 w-12">
                  <AvatarFallback>{getInitials(matchedUser.name)}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <CardTitle className="text-lg">{matchedUser.name}</CardTitle>
                  <CardDescription>
                    {matchedUser.age} years old • {matchedUser.location}
                  </CardDescription>
                </div>
                <Badge className="bg-green-500 hover:bg-green-600">
                  {matchedUser.matchScore}% Match
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <p className="text-sm">Similar needs:</p>
                <div className="flex flex-wrap gap-2">
                  {matchedUser.commonNeeds.map((need, idx) => (
                    <Badge key={idx} variant="secondary">
                      {need}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex gap-2">
                <Button className="flex-1">
                  <MessageCircle className="size-4 mr-2" />
                  Connect
                </Button>
                <Button variant="outline" size="icon">
                  <Heart className="size-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-dashed">
        <CardContent className="py-8 text-center text-muted-foreground">
          <Users className="size-12 mx-auto mb-2 opacity-50" />
          <p>More community members will appear as they join</p>
        </CardContent>
      </Card>
    </div>
  );
}
