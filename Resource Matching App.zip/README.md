
  # Resource Matching App

  This is a code bundle for Resource Matching App. The original project is available at https://www.figma.com/design/COhtN2wVWmtr6kSQQiHs7h/Resource-Matching-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  